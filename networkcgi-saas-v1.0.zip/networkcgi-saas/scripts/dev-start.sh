#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/backend"
[ -d .venv ] || python3 -m venv .venv
.venv/bin/pip install -q -r requirements.txt
[ -f .env ] || cp .env.example .env
.venv/bin/uvicorn app.main:app --reload --host 0.0.0.0 --port 8002 &
API_PID=$!
cd "$ROOT/frontend"
npm install
npm run dev
kill $API_PID 2>/dev/null || true
