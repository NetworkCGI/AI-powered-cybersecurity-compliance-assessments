#!/usr/bin/env bash
set -euo pipefail

APP_DIR=/opt/networkcgi
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "[1/8] Installing OS packages..."
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip nginx curl ca-certificates rsync

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Install Node 20+ and rerun this script."
  exit 1
fi

echo "[2/8] Copying NetworkCGI to $APP_DIR..."
sudo mkdir -p "$APP_DIR"
sudo rsync -a --delete --exclude '.env' --exclude 'networkcgi.db' "$SOURCE_DIR/" "$APP_DIR/"
sudo chown -R "$USER":"$USER" "$APP_DIR"

echo "[3/8] Creating Python environment..."
cd "$APP_DIR/backend"
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt

if [ ! -f .env ]; then
  cp .env.example .env
  SECRET=$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(48))
PY
)
  sed -i "s|SECRET_KEY=REPLACE_WITH_A_LONG_RANDOM_SECRET|SECRET_KEY=$SECRET|" .env
  echo "Created backend/.env. Add OPENAI_API_KEY and optional Stripe settings later."
fi

mkdir -p uploads

echo "[4/8] Building frontend..."
cd "$APP_DIR/frontend"
npm install
npm run build

echo "[5/8] Seeding demo workspace..."
cd "$APP_DIR/backend"
.venv/bin/python seed_demo.py || true

echo "[6/8] Setting permissions..."
sudo chown -R www-data:www-data "$APP_DIR/backend" "$APP_DIR/frontend/dist"
sudo chmod 640 "$APP_DIR/backend/.env"
sudo find "$APP_DIR/backend/uploads" -type d -exec chmod 750 {} \;

echo "[7/8] Installing systemd and Nginx..."
sudo cp "$APP_DIR/deploy/systemd/networkcgi-api.service" /etc/systemd/system/networkcgi-api.service
sudo cp "$APP_DIR/deploy/nginx/networkcgi.conf" /etc/nginx/sites-available/networkcgi
sudo ln -sf /etc/nginx/sites-available/networkcgi /etc/nginx/sites-enabled/networkcgi
sudo nginx -t
sudo systemctl daemon-reload
sudo systemctl enable --now networkcgi-api
sudo systemctl restart nginx

echo "[8/8] Health check..."
sleep 2
curl -fsS http://127.0.0.1:8002/api/health || true

echo
echo "============================================================"
echo "NetworkCGI installation complete"
echo "Open: http://SERVER-IP:8082/"
echo "Demo login: admin@networkcgi.com"
echo "Demo password: ChangeMe123!"
echo "IMPORTANT: Change/remove demo account before production."
echo "Environment file: /opt/networkcgi/backend/.env"
echo "API service: systemctl status networkcgi-api"
echo "============================================================"
