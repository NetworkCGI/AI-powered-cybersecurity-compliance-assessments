from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    app_name: str = "NetworkCGI SaaS"
    environment: str = "development"
    secret_key: str = "CHANGE-ME-IN-PRODUCTION"
    access_token_expire_minutes: int = 720
    database_url: str = f"sqlite:///{BASE_DIR / 'networkcgi.db'}"
    upload_dir: str = str(BASE_DIR / "uploads")
    allowed_origins: str = "http://localhost:3002,http://127.0.0.1:3002"

    openai_api_key: str = ""
    openai_model: str = "gpt-6-astra"

    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_price_starter: str = ""
    stripe_price_professional: str = ""
    stripe_price_business: str = ""
    stripe_success_url: str = "http://localhost:3002/billing?success=1"
    stripe_cancel_url: str = "http://localhost:3002/billing?canceled=1"

    model_config = SettingsConfigDict(env_file=BASE_DIR / ".env", extra="ignore")

    @property
    def origins(self) -> list[str]:
        return [x.strip() for x in self.allowed_origins.split(",") if x.strip()]


settings = Settings()
