from datetime import datetime
from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=200)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    organization_name: str = Field(min_length=2, max_length=200)
    industry: str = "General"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    role: str
    organization_id: int
    model_config = {"from_attributes": True}


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class AssessmentCreate(BaseModel):
    name: str
    framework: str = "NIST CSF 2.0"
    notes: str = ""


class AssessmentUpdate(BaseModel):
    name: str | None = None
    framework: str | None = None
    status: str | None = None
    score: float | None = None
    notes: str | None = None


class FindingCreate(BaseModel):
    assessment_id: int | None = None
    title: str
    severity: str = "Medium"
    status: str = "Open"
    control_ref: str = ""
    description: str = ""
    recommendation: str = ""
    owner: str = ""


class FindingUpdate(BaseModel):
    title: str | None = None
    severity: str | None = None
    status: str | None = None
    control_ref: str | None = None
    description: str | None = None
    recommendation: str | None = None
    owner: str | None = None


class RiskCreate(BaseModel):
    title: str
    likelihood: int = Field(default=3, ge=1, le=5)
    impact: int = Field(default=3, ge=1, le=5)
    status: str = "Open"
    treatment: str = ""


class AdvisorRequest(BaseModel):
    question: str = Field(min_length=2, max_length=4000)
    assessment_id: int | None = None


class CheckoutRequest(BaseModel):
    plan: str
