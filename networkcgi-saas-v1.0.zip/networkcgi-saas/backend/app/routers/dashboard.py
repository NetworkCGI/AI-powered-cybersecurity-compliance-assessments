from fastapi import APIRouter, Depends
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Assessment, Evidence, Finding, Risk, Subscription, Organization
from ..auth import get_current_user

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("")
def dashboard(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org_id = user.organization_id
    assessments = db.scalars(select(Assessment).where(Assessment.organization_id == org_id).order_by(Assessment.created_at.desc())).all()
    findings = db.scalars(select(Finding).where(Finding.organization_id == org_id)).all()
    risks = db.scalars(select(Risk).where(Risk.organization_id == org_id)).all()
    evidence_count = db.scalar(select(func.count(Evidence.id)).where(Evidence.organization_id == org_id)) or 0
    sub = db.scalar(select(Subscription).where(Subscription.organization_id == org_id))
    org = db.get(Organization, org_id)
    severity = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    for f in findings:
        severity[f.severity] = severity.get(f.severity, 0) + 1
    completed_scores = [a.score for a in assessments if a.score > 0]
    score = round(sum(completed_scores) / len(completed_scores), 1) if completed_scores else 0
    return {
        "organization": {"id": org.id, "name": org.name, "industry": org.industry},
        "subscription": {"plan": sub.plan if sub else "Starter", "status": sub.status if sub else "active"},
        "stats": {
            "security_score": score,
            "assessments": len(assessments),
            "evidence": evidence_count,
            "open_findings": sum(1 for f in findings if f.status.lower() != "closed"),
            "open_risks": sum(1 for r in risks if r.status.lower() != "closed"),
            "severity": severity,
        },
        "recent_assessments": [
            {"id": a.id, "name": a.name, "framework": a.framework, "status": a.status, "score": a.score, "created_at": a.created_at}
            for a in assessments[:5]
        ],
    }
