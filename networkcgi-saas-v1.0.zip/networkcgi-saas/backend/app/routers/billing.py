import hashlib
import hmac
import json
import time
import httpx
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Subscription
from ..schemas import CheckoutRequest
from ..auth import get_current_user
from ..config import settings

router = APIRouter(prefix="/api/billing", tags=["billing"])

PLANS = {
    "Starter": {"monthly": 99, "description": "1 organization, assessments, evidence, findings and reports"},
    "Professional": {"monthly": 299, "description": "AI Advisor, multiple assessments and advanced reporting"},
    "Business": {"monthly": 749, "description": "Larger teams, integrations and advanced workflows"},
}


def price_id(plan: str):
    return {
        "Starter": settings.stripe_price_starter,
        "Professional": settings.stripe_price_professional,
        "Business": settings.stripe_price_business,
    }.get(plan, "")


@router.get("/plans")
def plans(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sub = db.scalar(select(Subscription).where(Subscription.organization_id == user.organization_id))
    return {"plans": PLANS, "current": {"plan": sub.plan if sub else "Starter", "status": sub.status if sub else "active"}}


@router.post("/checkout")
def checkout(payload: CheckoutRequest, user: User = Depends(get_current_user)):
    if payload.plan not in PLANS:
        raise HTTPException(400, "Unknown plan")
    pid = price_id(payload.plan)
    if not settings.stripe_secret_key or not pid:
        raise HTTPException(503, "Stripe is not configured. Add Stripe keys and Price IDs to backend/.env.")
    form = {
        "mode": "subscription",
        "line_items[0][price]": pid,
        "line_items[0][quantity]": "1",
        "success_url": settings.stripe_success_url,
        "cancel_url": settings.stripe_cancel_url,
        "client_reference_id": str(user.organization_id),
        "customer_email": user.email,
        "metadata[organization_id]": str(user.organization_id),
        "metadata[plan]": payload.plan,
    }
    try:
        r = httpx.post(
            "https://api.stripe.com/v1/checkout/sessions",
            data=form,
            headers={"Authorization": f"Bearer {settings.stripe_secret_key}"},
            timeout=20,
        )
        data = r.json()
    except Exception as e:
        raise HTTPException(502, f"Stripe connection failed: {e}")
    if r.status_code >= 400:
        raise HTTPException(502, data.get("error", {}).get("message", "Stripe checkout failed"))
    return {"url": data.get("url")}


def verify_stripe_signature(payload: bytes, signature_header: str, secret: str, tolerance: int = 300):
    parts = {}
    for item in signature_header.split(","):
        if "=" in item:
            k, v = item.split("=", 1)
            parts.setdefault(k, []).append(v)
    try:
        timestamp = int(parts["t"][0])
        signatures = parts["v1"]
    except Exception:
        return False
    if abs(int(time.time()) - timestamp) > tolerance:
        return False
    signed = f"{timestamp}.".encode() + payload
    expected = hmac.new(secret.encode(), signed, hashlib.sha256).hexdigest()
    return any(hmac.compare_digest(expected, sig) for sig in signatures)


@router.post("/webhook")
async def webhook(request: Request, db: Session = Depends(get_db)):
    if not settings.stripe_webhook_secret:
        raise HTTPException(503, "Stripe webhook not configured")
    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")
    if not verify_stripe_signature(payload, sig, settings.stripe_webhook_secret):
        raise HTTPException(400, "Invalid webhook signature")
    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        raise HTTPException(400, "Invalid webhook payload")
    if event.get("type") == "checkout.session.completed":
        obj = event.get("data", {}).get("object", {})
        metadata = obj.get("metadata", {}) or {}
        raw_org = metadata.get("organization_id") or obj.get("client_reference_id")
        if raw_org:
            org_id = int(raw_org)
            plan = metadata.get("plan", "Professional")
            sub = db.scalar(select(Subscription).where(Subscription.organization_id == org_id))
            if sub:
                sub.plan = plan
                sub.status = "active"
                sub.stripe_customer_id = obj.get("customer") or ""
                sub.stripe_subscription_id = obj.get("subscription") or ""
                db.commit()
    return {"received": True}
