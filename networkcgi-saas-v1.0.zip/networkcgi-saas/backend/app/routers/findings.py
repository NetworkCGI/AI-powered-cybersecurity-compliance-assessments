from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Finding, Assessment
from ..schemas import FindingCreate, FindingUpdate
from ..auth import get_current_user

router = APIRouter(prefix="/api/findings", tags=["findings"])


def serialize(f):
    return {"id": f.id, "assessment_id": f.assessment_id, "title": f.title, "severity": f.severity, "status": f.status, "control_ref": f.control_ref, "description": f.description, "recommendation": f.recommendation, "owner": f.owner, "created_at": f.created_at}


@router.get("")
def list_findings(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Finding).where(Finding.organization_id == user.organization_id).order_by(Finding.created_at.desc())).all()
    return [serialize(f) for f in rows]


@router.post("")
def create_finding(payload: FindingCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if payload.assessment_id:
        a = db.get(Assessment, payload.assessment_id)
        if not a or a.organization_id != user.organization_id:
            raise HTTPException(404, "Assessment not found")
    f = Finding(organization_id=user.organization_id, **payload.model_dump())
    db.add(f); db.commit(); db.refresh(f)
    return serialize(f)


@router.patch("/{finding_id}")
def update_finding(finding_id: int, payload: FindingUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    f = db.get(Finding, finding_id)
    if not f or f.organization_id != user.organization_id:
        raise HTTPException(404, "Finding not found")
    for k, v in payload.model_dump(exclude_unset=True).items(): setattr(f, k, v)
    db.commit(); db.refresh(f)
    return serialize(f)
