from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Organization, Assessment, Finding, Risk, Evidence
from ..schemas import AdvisorRequest
from ..auth import get_current_user
from ..services.openai_service import ask_ai

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/advisor")
def advisor(payload: AdvisorRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = db.get(Organization, user.organization_id)
    q_assess = select(Assessment).where(Assessment.organization_id == user.organization_id)
    if payload.assessment_id:
        q_assess = q_assess.where(Assessment.id == payload.assessment_id)
    assessments = db.scalars(q_assess).all()
    findings = db.scalars(select(Finding).where(Finding.organization_id == user.organization_id)).all()
    risks = db.scalars(select(Risk).where(Risk.organization_id == user.organization_id)).all()
    evidence = db.scalars(select(Evidence).where(Evidence.organization_id == user.organization_id)).all()
    context = {
        "organization": {"name": org.name, "industry": org.industry, "size": org.size},
        "assessments": [{"name": a.name, "framework": a.framework, "status": a.status, "score": a.score, "notes": a.notes} for a in assessments[:20]],
        "findings": [{"title": f.title, "severity": f.severity, "status": f.status, "control_ref": f.control_ref, "description": f.description, "recommendation": f.recommendation} for f in findings[:100]],
        "risks": [{"title": r.title, "score": r.score, "status": r.status, "treatment": r.treatment} for r in risks[:100]],
        "evidence": [{"filename": e.filename, "description": e.description, "content_type": e.content_type} for e in evidence[:100]],
    }
    return {"answer": ask_ai(payload.question, context)}
