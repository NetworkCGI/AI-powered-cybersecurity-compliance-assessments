from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Assessment
from ..schemas import AssessmentCreate, AssessmentUpdate
from ..auth import get_current_user

router = APIRouter(prefix="/api/assessments", tags=["assessments"])


def serialize(a):
    return {"id": a.id, "name": a.name, "framework": a.framework, "status": a.status, "score": a.score, "notes": a.notes, "created_at": a.created_at, "updated_at": a.updated_at}


@router.get("")
def list_assessments(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Assessment).where(Assessment.organization_id == user.organization_id).order_by(Assessment.created_at.desc())).all()
    return [serialize(a) for a in rows]


@router.post("")
def create_assessment(payload: AssessmentCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = Assessment(organization_id=user.organization_id, **payload.model_dump())
    db.add(a); db.commit(); db.refresh(a)
    return serialize(a)


@router.patch("/{assessment_id}")
def update_assessment(assessment_id: int, payload: AssessmentUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = db.get(Assessment, assessment_id)
    if not a or a.organization_id != user.organization_id:
        raise HTTPException(404, "Assessment not found")
    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(a, k, v)
    db.commit(); db.refresh(a)
    return serialize(a)


@router.delete("/{assessment_id}")
def delete_assessment(assessment_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = db.get(Assessment, assessment_id)
    if not a or a.organization_id != user.organization_id:
        raise HTTPException(404, "Assessment not found")
    db.delete(a); db.commit()
    return {"ok": True}
