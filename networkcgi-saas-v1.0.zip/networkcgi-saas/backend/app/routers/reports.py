from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Organization, Assessment, Finding, Risk, Evidence
from ..auth import get_current_user
from ..services.report_service import build_assessment_pdf

router = APIRouter(prefix="/api/reports", tags=["reports"])


@router.get("/assessment/{assessment_id}.pdf")
def assessment_report(assessment_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    assessment = db.get(Assessment, assessment_id)
    if not assessment or assessment.organization_id != user.organization_id:
        raise HTTPException(404, "Assessment not found")
    org = db.get(Organization, user.organization_id)
    findings = db.scalars(select(Finding).where(Finding.organization_id == user.organization_id, Finding.assessment_id == assessment_id)).all()
    risks = db.scalars(select(Risk).where(Risk.organization_id == user.organization_id)).all()
    evidence = db.scalars(select(Evidence).where(Evidence.organization_id == user.organization_id, Evidence.assessment_id == assessment_id)).all()
    pdf = build_assessment_pdf(org, assessment, findings, risks, evidence)
    filename = f"NetworkCGI_{assessment.name.replace(' ', '_')}.pdf"
    return StreamingResponse(pdf, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{filename}"'})
