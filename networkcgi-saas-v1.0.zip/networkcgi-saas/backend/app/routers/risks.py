from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Risk
from ..schemas import RiskCreate
from ..auth import get_current_user

router = APIRouter(prefix="/api/risks", tags=["risks"])


def serialize(r):
    return {"id": r.id, "title": r.title, "likelihood": r.likelihood, "impact": r.impact, "score": r.score, "status": r.status, "treatment": r.treatment, "created_at": r.created_at}


@router.get("")
def list_risks(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Risk).where(Risk.organization_id == user.organization_id).order_by(Risk.score.desc())).all()
    return [serialize(r) for r in rows]


@router.post("")
def create_risk(payload: RiskCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    values = payload.model_dump(); values["score"] = values["likelihood"] * values["impact"]
    r = Risk(organization_id=user.organization_id, **values)
    db.add(r); db.commit(); db.refresh(r)
    return serialize(r)


@router.patch("/{risk_id}/close")
def close_risk(risk_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = db.get(Risk, risk_id)
    if not r or r.organization_id != user.organization_id:
        raise HTTPException(404, "Risk not found")
    r.status = "Closed"; db.commit(); db.refresh(r)
    return serialize(r)
