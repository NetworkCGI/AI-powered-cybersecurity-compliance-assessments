from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import User, Evidence, Assessment
from ..auth import get_current_user
from ..config import settings

router = APIRouter(prefix="/api/evidence", tags=["evidence"])
MAX_BYTES = 25 * 1024 * 1024


def serialize(e):
    return {"id": e.id, "assessment_id": e.assessment_id, "filename": e.filename, "content_type": e.content_type, "size_bytes": e.size_bytes, "description": e.description, "uploaded_at": e.uploaded_at}


@router.get("")
def list_evidence(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Evidence).where(Evidence.organization_id == user.organization_id).order_by(Evidence.uploaded_at.desc())).all()
    return [serialize(e) for e in rows]


@router.post("")
async def upload_evidence(
    file: UploadFile = File(...),
    assessment_id: int | None = Form(default=None),
    description: str = Form(default=""),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if assessment_id:
        a = db.get(Assessment, assessment_id)
        if not a or a.organization_id != user.organization_id:
            raise HTTPException(404, "Assessment not found")
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "File exceeds 25 MB limit")
    safe_name = Path(file.filename or "evidence.bin").name
    folder = Path(settings.upload_dir) / str(user.organization_id)
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"{uuid4().hex}_{safe_name}"
    stored.write_bytes(data)
    row = Evidence(
        organization_id=user.organization_id,
        assessment_id=assessment_id,
        filename=safe_name,
        stored_path=str(stored),
        content_type=file.content_type or "application/octet-stream",
        size_bytes=len(data),
        description=description,
    )
    db.add(row); db.commit(); db.refresh(row)
    return serialize(row)


@router.delete("/{evidence_id}")
def delete_evidence(evidence_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    e = db.get(Evidence, evidence_id)
    if not e or e.organization_id != user.organization_id:
        raise HTTPException(404, "Evidence not found")
    try:
        Path(e.stored_path).unlink(missing_ok=True)
    except OSError:
        pass
    db.delete(e); db.commit()
    return {"ok": True}
