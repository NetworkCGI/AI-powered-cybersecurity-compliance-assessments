import json
from ..config import settings

SYSTEM_GUIDANCE = """You are NetworkCGI AI Advisor, a cybersecurity and compliance assistant.
Use only the supplied organization context. Clearly distinguish observed facts from recommendations.
Do not claim an organization is certified or officially compliant. If evidence is incomplete, say so.
Prefer concise, actionable answers with prioritized remediation guidance.
"""


def ask_ai(question: str, context: dict) -> str:
    if not settings.openai_api_key:
        return (
            "AI Advisor is configured but OPENAI_API_KEY is not set. "
            "Add the key to backend/.env and restart the API.\n\n"
            f"Question received: {question}"
        )
    try:
        from openai import OpenAI
    except ImportError as e:
        return f"OpenAI SDK is not installed on the server: {e}"
    client = OpenAI(api_key=settings.openai_api_key)
    payload = json.dumps(context, default=str)[:30000]
    response = client.responses.create(
        model=settings.openai_model,
        input=[
            {"role": "system", "content": SYSTEM_GUIDANCE},
            {"role": "user", "content": f"Organization context:\n{payload}\n\nUser question:\n{question}"},
        ],
    )
    return response.output_text
