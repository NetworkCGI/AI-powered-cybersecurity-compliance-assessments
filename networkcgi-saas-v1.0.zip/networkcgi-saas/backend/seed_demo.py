from sqlalchemy import select
from app.db import SessionLocal, Base, engine
from app.models import Organization, User, Subscription, Assessment, Finding, Risk
from app.auth import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()
try:
    if db.scalar(select(User).where(User.email == "admin@networkcgi.com")):
        print("Demo user already exists")
        raise SystemExit
    org = Organization(name="NetworkCGI Demo", industry="Cybersecurity", size="1-25")
    db.add(org); db.flush()
    user = User(email="admin@networkcgi.com", full_name="NetworkCGI Admin", password_hash=hash_password("ChangeMe123!"), role="admin", organization_id=org.id)
    db.add(user)
    db.add(Subscription(organization_id=org.id, plan="Professional", status="active"))
    a = Assessment(organization_id=org.id, name="Baseline Security Assessment", framework="NIST CSF 2.0", status="In Progress", score=76, notes="Initial demo assessment")
    db.add(a); db.flush()
    db.add_all([
        Finding(organization_id=org.id, assessment_id=a.id, title="MFA not enforced for all users", severity="High", control_ref="PR.AA", description="Evidence indicates MFA coverage is incomplete.", recommendation="Enforce MFA for all interactive users and privileged accounts."),
        Finding(organization_id=org.id, assessment_id=a.id, title="Backup restore testing not documented", severity="Medium", control_ref="RC.RP", description="Backups are reported but restore-test evidence is unavailable.", recommendation="Perform and document quarterly restore testing."),
    ])
    db.add(Risk(organization_id=org.id, title="Account compromise due to incomplete MFA coverage", likelihood=4, impact=5, score=20, treatment="Enforce MFA and review exceptions."))
    db.commit()
    print("Created demo login: admin@networkcgi.com / ChangeMe123!")
finally:
    db.close()
