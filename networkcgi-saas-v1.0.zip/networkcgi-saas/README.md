# NetworkCGI SaaS v1.0

AI-powered cybersecurity, compliance assessment, evidence management, risk tracking and executive reporting.

## Included and working

- Customer registration and login with JWT authentication
- Organization-level tenant isolation
- Executive dashboard
- Security/compliance assessments
- NIST CSF 2.0, NIST 800-171, CIS Controls v8, CMMC 2.0 and Custom framework choices
- Evidence upload with per-organization storage
- Findings with severity, control reference and remediation
- 5x5 risk register
- AI Security Advisor using the OpenAI Responses API
- Branded PDF assessment reports
- Starter / Professional / Business plan interface
- Optional Stripe subscription Checkout + webhook
- SQLite first-run mode and PostgreSQL support
- React/Vite responsive customer UI
- FastAPI backend with OpenAPI docs
- Nginx configuration
- systemd service
- one-command Ubuntu install script
- Docker Compose alternative

## Ports

- Frontend development: 3002
- Backend API: 8002
- Initial packaged Nginx web: 8082 (keeps the cloned SecureOps site untouched)

These ports intentionally avoid the typical ControlTrace/SecureOps ports and are easy to change.

---

# Fastest installation on the duplicated SecureOps Ubuntu server

Upload/extract this folder somewhere such as `/home/<user>/networkcgi-saas`, then:

```bash
cd networkcgi-saas
chmod +x scripts/install.sh
./scripts/install.sh
```

The installer copies the final application to:

```text
/opt/networkcgi
```

Then browse to:

```text
http://YOUR-SERVER-IP:8082/
```

Demo login:

```text
admin@networkcgi.com
ChangeMe123!
```

**Delete or change the demo account before exposing the application to the Internet.**

---

# OpenAI setup

Edit:

```bash
sudo nano /opt/networkcgi/backend/.env
```

Set:

```text
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-6-astra
```

Then:

```bash
sudo systemctl restart networkcgi-api
```

If the key is blank, the application still runs; the AI Advisor returns a configuration message instead of failing.

The key stays on the FastAPI server and is never sent to the React browser.

---

# Database

The package defaults to SQLite for the easiest first successful run:

```text
DATABASE_URL=sqlite:////opt/networkcgi/backend/networkcgi.db
```

For production, PostgreSQL is recommended. Example:

```text
DATABASE_URL=postgresql+psycopg://networkcgi:STRONG_PASSWORD@127.0.0.1:5432/networkcgi
```

Install PostgreSQL and create the database/user, update `.env`, then restart the API.

---

# Stripe subscriptions

The Billing page works without Stripe and shows the product plans. To enable real subscription checkout:

1. Create Stripe recurring prices for Starter, Professional and Business.
2. Add the following values to `/opt/networkcgi/backend/.env`:

```text
STRIPE_SECRET_KEY=sk_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_STARTER=price_...
STRIPE_PRICE_PROFESSIONAL=price_...
STRIPE_PRICE_BUSINESS=price_...
STRIPE_SUCCESS_URL=https://yourdomain.com/billing?success=1
STRIPE_CANCEL_URL=https://yourdomain.com/billing?canceled=1
```

3. Configure the Stripe webhook URL as:

```text
https://yourdomain.com/api/billing/webhook
```

4. Restart the API.

---

# Useful commands

API status:

```bash
sudo systemctl status networkcgi-api
```

Restart API:

```bash
sudo systemctl restart networkcgi-api
```

View API logs:

```bash
sudo journalctl -u networkcgi-api -f
```

Check Nginx:

```bash
sudo nginx -t
sudo systemctl status nginx
```

API health:

```bash
curl http://127.0.0.1:8002/api/health
```

API documentation:

```text
http://SERVER-IP:8082/api/docs
```

Note: in the supplied Nginx config `/api/docs` is proxied to FastAPI automatically.

---

# Rebuild the React UI after changes

```bash
cd /opt/networkcgi/frontend
sudo -u www-data npm install
sudo -u www-data npm run build
sudo systemctl reload nginx
```

If permissions make npm inconvenient, build as your deployment user and then run:

```bash
sudo chown -R www-data:www-data /opt/networkcgi/frontend/dist
```

---

# HTTPS / public deployment

Once DNS points to the server, install Certbot and issue a certificate:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

Then update `ALLOWED_ORIGINS`, Stripe success/cancel URLs and any DNS-specific settings in `.env`.

---

# Security before public production

The package is designed to run now, but before storing real customer evidence you should complete production hardening:

- Use PostgreSQL rather than SQLite.
- Use a strong unique `SECRET_KEY`.
- Remove/change the demo account.
- Enable HTTPS only.
- Put API secrets in a protected environment/secret store.
- Add server firewall rules.
- Add malware/content scanning for evidence uploads if accepting untrusted files.
- Configure backups for database and evidence storage.
- Add Entra ID/OIDC or stronger MFA for production customer authentication.
- Add email verification and password reset.
- Configure centralized application/audit logs.
- Establish data retention and customer deletion procedures.
- Move evidence to object storage (Azure Blob is a good future target) for larger deployments.
- Have legal/privacy terms reviewed before commercial launch.

---

# Architecture

```text
Browser
  |
  v
React / Vite UI
  |
  v
Nginx
  |
  +---- /api ----> FastAPI :8002
                    |
                    +---- SQLAlchemy -> SQLite/PostgreSQL
                    |
                    +---- Evidence Storage
                    |
                    +---- OpenAI Responses API
                    |
                    +---- Stripe (optional)
```

## Multi-tenancy

Every operational record stores an `organization_id`, and API queries scope records to the authenticated user's organization. This is the v1 tenant boundary.

## Product direction

NetworkCGI is the customer-facing SaaS portal. ControlTrace and SecureOps can later become connected modules/engines behind the same organization, identity, subscription and reporting layer instead of being rebuilt from scratch.
