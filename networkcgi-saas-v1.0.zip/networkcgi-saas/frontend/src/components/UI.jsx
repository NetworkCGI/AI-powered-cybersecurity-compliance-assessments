export function PageHeader({ eyebrow, title, text, actions }) {
  return <div className="page-header"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2>{text && <p>{text}</p>}</div>{actions && <div className="page-actions">{actions}</div>}</div>
}
export function Card({ children, className='' }) { return <div className={`card ${className}`}>{children}</div> }
export function Empty({ title, text }) { return <div className="empty"><div className="empty-icon">+</div><strong>{title}</strong><p>{text}</p></div> }
export function Severity({ value }) { return <span className={`severity ${String(value).toLowerCase()}`}>{value}</span> }
export function Loading(){ return <div className="loading"><span></span><p>Loading NetworkCGI...</p></div> }
export function ErrorBox({error}) { return error ? <div className="error-box">{error}</div> : null }
