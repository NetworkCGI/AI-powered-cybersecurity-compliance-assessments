import { NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, ClipboardCheck, FileStack, TriangleAlert, ShieldAlert,
  Sparkles, FileText, CreditCard, LogOut, Network, Menu, X
} from 'lucide-react'
import { useState } from 'react'
import { clearAuth } from '../api'

const nav = [
  ['/', 'Dashboard', LayoutDashboard],
  ['/assessments', 'Assessments', ClipboardCheck],
  ['/evidence', 'Evidence', FileStack],
  ['/findings', 'Findings', TriangleAlert],
  ['/risks', 'Risks', ShieldAlert],
  ['/advisor', 'AI Advisor', Sparkles],
  ['/reports', 'Reports', FileText],
  ['/billing', 'Billing', CreditCard],
]

export default function Layout({ children }) {
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()
  const user = JSON.parse(localStorage.getItem('networkcgi_user') || '{}')
  const logout = () => { clearAuth(); navigate('/login') }
  return <div className="app-shell">
    <aside className={`sidebar ${open ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark"><Network size={24}/></div><div><strong>NETWORKCGI</strong><small>Security Intelligence</small></div></div>
      <button className="mobile-close" onClick={() => setOpen(false)}><X/></button>
      <nav>{nav.map(([to, label, Icon]) => <NavLink key={to} to={to} end={to === '/'} onClick={() => setOpen(false)} className={({isActive}) => isActive ? 'active' : ''}><Icon size={18}/><span>{label}</span></NavLink>)}</nav>
      <div className="sidebar-foot">
        <div className="user-chip"><span className="avatar">{(user.full_name || 'U').slice(0,1).toUpperCase()}</span><div><strong>{user.full_name || 'User'}</strong><small>{user.email || ''}</small></div></div>
        <button className="ghost wide" onClick={logout}><LogOut size={16}/> Sign out</button>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="menu-btn" onClick={() => setOpen(true)}><Menu/></button><div><span className="eyebrow">NETWORKCGI SAAS</span><h1>AI-Powered Cybersecurity & Compliance</h1></div><span className="status-pill"><i></i> Platform Online</span></header>
      <section className="content">{children}</section>
    </main>
  </div>
}
