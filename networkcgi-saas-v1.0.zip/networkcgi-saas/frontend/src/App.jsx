import { Routes, Route, Navigate } from 'react-router-dom'
import { getToken } from './api'
import Layout from './components/Layout'
import { Login, Register } from './pages/Auth'
import Dashboard from './pages/Dashboard'
import Assessments from './pages/Assessments'
import Evidence from './pages/Evidence'
import Findings from './pages/Findings'
import Risks from './pages/Risks'
import Advisor from './pages/Advisor'
import Reports from './pages/Reports'
import Billing from './pages/Billing'

function Protected({children}){return getToken()?<Layout>{children}</Layout>:<Navigate to="/login" replace/>}
export default function App(){return <Routes><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/><Route path="/" element={<Protected><Dashboard/></Protected>}/><Route path="/assessments" element={<Protected><Assessments/></Protected>}/><Route path="/evidence" element={<Protected><Evidence/></Protected>}/><Route path="/findings" element={<Protected><Findings/></Protected>}/><Route path="/risks" element={<Protected><Risks/></Protected>}/><Route path="/advisor" element={<Protected><Advisor/></Protected>}/><Route path="/reports" element={<Protected><Reports/></Protected>}/><Route path="/billing" element={<Protected><Billing/></Protected>}/><Route path="*" element={<Navigate to="/"/>}/></Routes>}
