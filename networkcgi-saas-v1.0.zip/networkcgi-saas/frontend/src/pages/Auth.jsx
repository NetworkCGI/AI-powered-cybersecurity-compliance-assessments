import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react'
import { api, setAuth } from '../api'

export function Login(){
  const [form,setForm]=useState({email:'admin@networkcgi.com',password:'ChangeMe123!'})
  const [error,setError]=useState(''); const [busy,setBusy]=useState(false); const nav=useNavigate()
  async function submit(e){e.preventDefault(); setBusy(true); setError(''); try{const data=await api('/api/auth/login',{method:'POST',body:JSON.stringify(form)}); setAuth(data); nav('/')}catch(e){setError(e.message)}finally{setBusy(false)}}
  return <AuthShell><form className="auth-card" onSubmit={submit}><span className="eyebrow">WELCOME BACK</span><h2>Sign in to NetworkCGI</h2><p>Access your security, compliance and risk workspace.</p>{error&&<div className="error-box">{error}</div>}<label>Email<input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} type="email" required/></label><label>Password<input value={form.password} onChange={e=>setForm({...form,password:e.target.value})} type="password" required/></label><button className="primary big" disabled={busy}>{busy?'Signing in...':'Sign In'} <ArrowRight size={18}/></button><small>New organization? <Link to="/register">Create an account</Link></small></form></AuthShell>
}

export function Register(){
  const [form,setForm]=useState({full_name:'',email:'',password:'',organization_name:'',industry:'General'})
  const [error,setError]=useState(''); const [busy,setBusy]=useState(false); const nav=useNavigate()
  async function submit(e){e.preventDefault(); setBusy(true); setError(''); try{const data=await api('/api/auth/register',{method:'POST',body:JSON.stringify(form)}); setAuth(data); nav('/')}catch(e){setError(e.message)}finally{setBusy(false)}}
  return <AuthShell><form className="auth-card" onSubmit={submit}><span className="eyebrow">START YOUR WORKSPACE</span><h2>Create NetworkCGI account</h2><p>Your first organization and Starter workspace are created automatically.</p>{error&&<div className="error-box">{error}</div>}<div className="two"><label>Full name<input value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} required/></label><label>Organization<input value={form.organization_name} onChange={e=>setForm({...form,organization_name:e.target.value})} required/></label></div><label>Industry<input value={form.industry} onChange={e=>setForm({...form,industry:e.target.value})}/></label><label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/></label><label>Password<input type="password" minLength="8" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required/></label><button className="primary big" disabled={busy}>{busy?'Creating...':'Create Workspace'} <ArrowRight size={18}/></button><small>Already have an account? <Link to="/login">Sign in</Link></small></form></AuthShell>
}

function AuthShell({children}){return <div className="auth-page"><div className="auth-hero"><div className="hero-logo"><ShieldCheck size={34}/><strong>NETWORKCGI</strong></div><h1>Turn security data into <span>actionable decisions.</span></h1><p>Assess risk, organize evidence, track remediation and use AI to accelerate cybersecurity and compliance work.</p><ul><li><CheckCircle2/> Multi-tenant security workspace</li><li><CheckCircle2/> NIST, CIS and CMMC-ready assessment model</li><li><CheckCircle2/> AI security advisor and executive reporting</li></ul></div>{children}</div>}
