import { useEffect, useState } from 'react'
import { ShieldCheck, ClipboardCheck, FileStack, TriangleAlert, Activity, ArrowUpRight } from 'lucide-react'
import { api } from '../api'
import { Card, Loading, ErrorBox, PageHeader, Severity } from '../components/UI'

export default function Dashboard(){
 const [data,setData]=useState(null),[error,setError]=useState('')
 useEffect(()=>{api('/api/dashboard').then(setData).catch(e=>setError(e.message))},[])
 if(error)return <ErrorBox error={error}/>; if(!data)return <Loading/>; const s=data.stats
 const stats=[['Security Score',`${s.security_score}%`,ShieldCheck],['Assessments',s.assessments,ClipboardCheck],['Evidence Files',s.evidence,FileStack],['Open Findings',s.open_findings,TriangleAlert]]
 return <><PageHeader eyebrow="EXECUTIVE OVERVIEW" title={data.organization.name} text={`${data.organization.industry} • ${data.subscription.plan} plan`} actions={<button className="primary" onClick={()=>location.href='/assessments'}>Start Assessment <ArrowUpRight size={16}/></button>}/>
 <div className="stats-grid">{stats.map(([l,v,I])=><Card key={l} className="stat"><div className="stat-icon"><I/></div><div><span>{l}</span><strong>{v}</strong></div></Card>)}</div>
 <div className="dash-grid"><Card><div className="card-head"><div><span className="eyebrow">RISK SIGNAL</span><h3>Findings by severity</h3></div><Activity/></div><div className="severity-bars">{Object.entries(s.severity).map(([k,v])=><div className="bar-row" key={k}><div><Severity value={k}/><b>{v}</b></div><div className="bar"><i style={{width:`${Math.min(100,v*12)}%`}}></i></div></div>)}</div></Card><Card><div className="card-head"><div><span className="eyebrow">LATEST WORK</span><h3>Recent assessments</h3></div></div>{data.recent_assessments.length? <div className="list">{data.recent_assessments.map(a=><div className="list-row" key={a.id}><div><strong>{a.name}</strong><small>{a.framework}</small></div><div className="right"><span>{a.status}</span><b>{a.score}%</b></div></div>)}</div>:<p className="muted">No assessments yet.</p>}</Card></div>
 <Card className="callout"><div><span className="eyebrow">AI SECURITY ADVISOR</span><h3>Ask questions across your current assessment data.</h3><p>NetworkCGI can use your findings, risks, evidence metadata and assessment context to help prioritize remediation.</p></div><button className="secondary" onClick={()=>location.href='/advisor'}>Open AI Advisor</button></Card></>
}
