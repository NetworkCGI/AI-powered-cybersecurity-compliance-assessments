const BASE = ''

export function getToken() {
  return localStorage.getItem('networkcgi_token') || ''
}

export function setAuth(data) {
  localStorage.setItem('networkcgi_token', data.access_token)
  localStorage.setItem('networkcgi_user', JSON.stringify(data.user))
}

export function clearAuth() {
  localStorage.removeItem('networkcgi_token')
  localStorage.removeItem('networkcgi_user')
}

export async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) }
  const token = getToken()
  if (token) headers.Authorization = `Bearer ${token}`
  if (options.body && !(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json'
  }
  const res = await fetch(`${BASE}${path}`, { ...options, headers })
  if (res.status === 401) {
    clearAuth()
    window.location.href = '/login'
    throw new Error('Session expired')
  }
  if (!res.ok) {
    let msg = `Request failed (${res.status})`
    try { msg = (await res.json()).detail || msg } catch {}
    throw new Error(msg)
  }
  const type = res.headers.get('content-type') || ''
  return type.includes('application/json') ? res.json() : res
}
